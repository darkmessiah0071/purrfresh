// PurrFresh Background Service Worker
// Extension ID: mdkenbajidgplificinngoiicipjlepof

importScripts('ExtPay.js');

const EXTENSION_ID = 'mdkenbajidgplificinngoiicipjlepof';
const extpay = ExtPay(EXTENSION_ID);

const PLANS = {
  free:     { slug: null,       dailyLimit: 10,       maxFavorites: 3    },
  monthly:  { slug: 'monthly',  dailyLimit: Infinity, maxFavorites: Infinity },
  yearly:   { slug: 'yearly',   dailyLimit: Infinity, maxFavorites: Infinity },
  lifetime: { slug: 'lifetime', dailyLimit: Infinity, maxFavorites: Infinity },
};

// How many images to keep pre-fetched in the buffer
const BUFFER_TARGET = 8;
const BUFFER_REFILL_THRESHOLD = 3;

// Rate-limit state (in-memory, resets with service worker)
let rateLimitUntil = 0;      // timestamp ms
let consecutiveErrors = 0;

extpay.startBackground();

// ── Install / startup ────────────────────────────────────────────────
chrome.runtime.onInstalled.addListener(async (details) => {
  if (details.reason === 'install') {
    await chrome.storage.local.set({
      seenIds:       [],
      favorites:     [],
      dailyCount:    0,
      dailyDate:     getTodayString(),
      apiKey:        '',
      settings:      { theme: 'auto', showBreed: true },
      totalCatsSeen: 0,
      imageBuffer:   [],  // pre-fetched images ready to serve
      lastViewedImage: null, // shown on popup open
    });
  }
  await setupDailyResetAlarm();
  // Pre-warm buffer after install
  setTimeout(() => fillBuffer(), 2000);
});

chrome.runtime.onStartup.addListener(async () => {
  await checkAndResetDaily();
  await setupDailyResetAlarm();
  setTimeout(() => fillBuffer(), 1000);
});

// ── Daily reset alarm ────────────────────────────────────────────────
async function setupDailyResetAlarm() {
  await chrome.alarms.clear('purrfresh-daily-reset');
  const now = new Date();
  const midnight = new Date(now);
  midnight.setHours(24, 0, 0, 0);
  chrome.alarms.create('purrfresh-daily-reset', {
    delayInMinutes: (midnight - now) / 60000,
    periodInMinutes: 1440,
  });
}

chrome.alarms.onAlarm.addListener(async (alarm) => {
  if (alarm.name === 'purrfresh-daily-reset') {
    await checkAndResetDaily();
    await fillBuffer();
  }
});

async function checkAndResetDaily() {
  const { dailyDate } = await chrome.storage.local.get('dailyDate');
  const today = getTodayString();
  if (dailyDate !== today) {
    await chrome.storage.local.set({ dailyDate: today, dailyCount: 0 });
  }
}

function getTodayString() {
  return new Date().toISOString().slice(0, 10);
}

// ── Image Buffer: Pre-fetch images to avoid latency & rate limits ────
let isFilling = false;

async function fillBuffer() {
  if (isFilling) return;
  if (Date.now() < rateLimitUntil) return; // still rate-limited

  isFilling = true;
  try {
    const { imageBuffer = [], seenIds = [], apiKey = '' } = await chrome.storage.local.get(['imageBuffer', 'seenIds', 'apiKey']);

    const needed = BUFFER_TARGET - imageBuffer.length;
    if (needed <= 0) { isFilling = false; return; }

    const seenSet = new Set(seenIds);
    // Also exclude IDs already in buffer
    imageBuffer.forEach(img => seenSet.add(img.id));

    const fetched = [];
    let attempts = 0;
    const maxAttempts = Math.ceil(needed / 10) + 2;

    while (fetched.length < needed && attempts < maxAttempts) {
      attempts++;
      try {
        const batch = await fetchBatch(apiKey, seenSet);
        batch.forEach(img => {
          if (!seenSet.has(img.id)) {
            seenSet.add(img.id);
            fetched.push(img);
          }
        });
        consecutiveErrors = 0;
      } catch (err) {
        consecutiveErrors++;
        if (err.message === 'RATE_LIMITED') {
          // Backoff: 2^errors * 30 seconds, max 10 minutes
          const backoffMs = Math.min(Math.pow(2, consecutiveErrors) * 30000, 600000);
          rateLimitUntil = Date.now() + backoffMs;
          console.log(`[PurrFresh] Rate limited, backing off ${backoffMs/1000}s`);
          break;
        }
        if (err.message === 'NETWORK_ERROR') break;
        break;
      }
    }

    if (fetched.length > 0) {
      const newBuffer = [...imageBuffer, ...fetched].slice(0, BUFFER_TARGET + 2);
      await chrome.storage.local.set({ imageBuffer: newBuffer });
      console.log(`[PurrFresh] Buffer filled: ${newBuffer.length} images ready`);
    }
  } catch (e) {
    console.error('[PurrFresh] fillBuffer error:', e);
  } finally {
    isFilling = false;
  }
}

async function fetchBatch(apiKey, seenSet) {
  const url = 'https://api.thecatapi.com/v1/images/search?limit=10&order=RAND';
  const headers = {};
  if (apiKey) headers['x-api-key'] = apiKey;

  let response;
  try {
    response = await fetch(url, { headers });
  } catch {
    throw new Error('NETWORK_ERROR');
  }

  if (response.status === 429) throw new Error('RATE_LIMITED');
  if (response.status === 401) throw new Error('INVALID_KEY');
  if (!response.ok)            throw new Error('API_ERROR');

  const images = await response.json();
  if (!Array.isArray(images) || images.length === 0) return [];

  return images
    .filter(img => !seenSet.has(img.id))
    .map(img => ({
      id:     img.id,
      url:    img.url,
      width:  img.width,
      height: img.height,
      breeds: img.breeds || [],
    }));
}

// ── Message handler ──────────────────────────────────────────────────
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {

  if (message.type === 'GET_STATE') {
    getFullState()
      .then(s => sendResponse({ success: true, data: s }))
      .catch(e => sendResponse({ success: false, error: e.message }));
    return true;
  }

  if (message.type === 'FETCH_CAT') {
    serveFromBufferOrFetch(message.apiKey)
      .then(r => sendResponse({ success: true, data: r }))
      .catch(e => sendResponse({ success: false, error: e.message }));
    return true;
  }

  if (message.type === 'PREFILL_BUFFER') {
    fillBuffer().then(() => sendResponse({ success: true }));
    return true;
  }

  if (message.type === 'RESET_SEEN') {
    chrome.storage.local.set({ seenIds: [], imageBuffer: [] })
      .then(() => { fillBuffer(); sendResponse({ success: true }); });
    return true;
  }

  if (message.type === 'OPEN_VIEWER') {
    openCatViewer(message.image);
    sendResponse({ success: true });
    return false;
  }

  if (message.type === 'OPEN_PAYMENT') {
    extpay.openPaymentPage(message.planSlug || null);
    sendResponse({ success: true });
    return false;
  }

  if (message.type === 'OPEN_LOGIN') {
    extpay.openLoginPage();
    sendResponse({ success: true });
    return false;
  }

  if (message.type === 'REFRESH_USER') {
    extpay.getUser()
      .then(u => sendResponse({ success: true, user: u }))
      .catch(e => sendResponse({ success: false, error: e.message }));
    return true;
  }
});

// ── Serve image: buffer first, live fetch fallback ───────────────────
async function serveFromBufferOrFetch(apiKey = '') {
  const today = getTodayString();
  const [storageData, extpayUser] = await Promise.all([
    chrome.storage.local.get(['seenIds', 'dailyCount', 'dailyDate', 'totalCatsSeen', 'imageBuffer', 'apiKey']),
    extpay.getUser().catch(() => ({ paid: false, paidPlan: null })),
  ]);

  const tier       = deriveTier(extpayUser);
  const plan       = PLANS[tier];
  const dailyCount = storageData.dailyDate === today ? (storageData.dailyCount || 0) : 0;

  if (plan.dailyLimit !== Infinity && dailyCount >= plan.dailyLimit) {
    throw new Error('DAILY_LIMIT_REACHED');
  }

  const seenSet    = new Set(storageData.seenIds || []);
  const buffer     = storageData.imageBuffer || [];
  const effectiveKey = apiKey || storageData.apiKey || '';

  // Try buffer first (instant, no API call)
  const bufferedIdx = buffer.findIndex(img => !seenSet.has(img.id));
  let image;

  if (bufferedIdx >= 0) {
    image = buffer[bufferedIdx];
    // Remove from buffer
    const newBuffer = buffer.filter((_, i) => i !== bufferedIdx);
    // Mark seen
    seenSet.add(image.id);
    const newDailyCount = dailyCount + 1;
    const newTotal      = (storageData.totalCatsSeen || 0) + 1;

    await chrome.storage.local.set({
      seenIds:       Array.from(seenSet),
      dailyCount:    newDailyCount,
      dailyDate:     today,
      totalCatsSeen: newTotal,
      imageBuffer:   newBuffer,
      lastViewedImage: image,
    });

    // Refill buffer if running low (async, don't block)
    if (newBuffer.length <= BUFFER_REFILL_THRESHOLD) {
      setTimeout(() => fillBuffer(), 500);
    }

    return { ...image, dailyCount: newDailyCount, totalSeen: newTotal, tier, plan, fromBuffer: true };
  }

  // Buffer miss — live fetch with rate-limit awareness
  if (Date.now() < rateLimitUntil) {
    throw new Error('RATE_LIMITED');
  }

  for (let attempt = 0; attempt < 6; attempt++) {
    let batch;
    try {
      batch = await fetchBatch(effectiveKey, seenSet);
      consecutiveErrors = 0;
    } catch (err) {
      consecutiveErrors++;
      if (err.message === 'RATE_LIMITED') {
        const backoffMs = Math.min(Math.pow(2, consecutiveErrors) * 30000, 600000);
        rateLimitUntil = Date.now() + backoffMs;
        throw new Error('RATE_LIMITED');
      }
      throw err;
    }

    const fresh = batch.find(img => !seenSet.has(img.id));
    if (fresh) {
      image = fresh;
      seenSet.add(image.id);
      const newDailyCount = dailyCount + 1;
      const newTotal      = (storageData.totalCatsSeen || 0) + 1;

      await chrome.storage.local.set({
        seenIds:       Array.from(seenSet),
        dailyCount:    newDailyCount,
        dailyDate:     today,
        totalCatsSeen: newTotal,
        lastViewedImage: image,
      });

      setTimeout(() => fillBuffer(), 500);
      return { ...image, dailyCount: newDailyCount, totalSeen: newTotal, tier, plan };
    }
  }

  throw new Error('ALL_CATS_SEEN');
}

// ── Open cat viewer window ────────────────────────────────────────────
async function openCatViewer(image) {
  await chrome.storage.local.set({ _viewer_image: image });

  const viewerUrl = chrome.runtime.getURL('catviewer.html');

  // Chrome adds ~16px to window width and ~88px to height for the popup chrome frame.
  // We want the VIEWPORT to equal the image size so no background is ever visible.
  const CHROME_W_OFFSET = 16;
  const CHROME_H_OFFSET = 88; // title bar + bottom chrome
  const TOOLBAR_H       = 44; // our own toolbar inside the page
  const STATUSBAR_H     = 28; // our own statusbar

  const MAX_W = 1380;
  const MAX_H = 860;

  let imgW = image.width  || 800;
  let imgH = image.height || 600;

  // Max available viewport
  const maxVpW = MAX_W - CHROME_W_OFFSET;
  const maxVpH = MAX_H - CHROME_H_OFFSET - TOOLBAR_H - STATUSBAR_H;

  // Scale so image fits fully within max bounds, maintaining aspect ratio
  const scaleW = Math.min(1, maxVpW / imgW);
  const scaleH = Math.min(1, maxVpH / imgH);
  const scale  = Math.min(scaleW, scaleH);

  // Viewport = exactly scaled image size
  const vpW = Math.round(imgW * scale);
  const vpH = Math.round(imgH * scale);

  // Total window size
  const winW = vpW + CHROME_W_OFFSET;
  const winH = vpH + TOOLBAR_H + STATUSBAR_H + CHROME_H_OFFSET;

  // Store the target viewport size so catviewer.js knows the exact scale to use
  await chrome.storage.local.set({
    _viewer_image: { ...image, _targetVpW: vpW, _targetVpH: vpH, _initScale: scale }
  });

  chrome.windows.create({
    url:     viewerUrl,
    type:    'popup',
    width:   winW,
    height:  winH,
    focused: true,
  });
}

// ── Helpers ───────────────────────────────────────────────────────────
function deriveTier(user) {
  if (!user || !user.paid) return 'free';
  return user.paidPlan || 'monthly';
}

async function getFullState() {
  const [data, extpayUser] = await Promise.all([
    chrome.storage.local.get([
      'seenIds', 'favorites', 'dailyCount', 'dailyDate',
      'apiKey', 'settings', 'totalCatsSeen', 'imageBuffer', 'lastViewedImage'
    ]),
    extpay.getUser().catch(() => ({ paid: false, paidPlan: null })),
  ]);

  const today = getTodayString();
  return {
    ...data,
    dailyCount:  data.dailyDate === today ? (data.dailyCount || 0) : 0,
    tier:        deriveTier(extpayUser),
    extpayUser,
    bufferSize:  (data.imageBuffer || []).length,
    plans:       PLANS,
  };
}
