// ExtPay.js - Complete MV3 Implementation for PurrFresh
// Extension ID: mdkenbajidgplificinngoiicipjlepof

function ExtPay(extensionId) {
  const HOST = 'https://extensionpay.com';

  function parseUser(u) {
    if (!u) return { paid: false, paidPlan: null, installedAt: new Date() };
    return {
      paid:            u.paid || false,
      paidPlan:        u.paidPlan || null,
      installedAt:     u.installedAt  ? new Date(u.installedAt)  : new Date(),
      trialStartedAt:  u.trialStartedAt ? new Date(u.trialStartedAt) : null,
      email:           u.email || null,
    };
  }

  async function getStoredUser() {
    return new Promise(resolve => {
      chrome.storage.local.get('_extpay_user', r => resolve(r._extpay_user || null));
    });
  }

  async function setStoredUser(user) {
    return new Promise(resolve => chrome.storage.local.set({ _extpay_user: user }, resolve));
  }

  async function getUser() {
    try {
      const resp = await fetch(
        `${HOST}/api/v1/extension/${extensionId}/payments/user`,
        { headers: { 'Accept': 'application/json', 'X-ExtPay-Extension-Id': extensionId } }
      );
      if (resp.status === 401 || resp.status === 404) {
        return parseUser({ paid: false, paidPlan: null, installedAt: new Date().toISOString() });
      }
      if (!resp.ok) throw new Error(`HTTP ${resp.status}`);
      const data = await resp.json();
      await setStoredUser(data);
      return parseUser(data);
    } catch {
      const stored = await getStoredUser();
      return parseUser(stored);
    }
  }

  function openPaymentPage(planSlug) {
    let url = `${HOST}/pay/${extensionId}`;
    if (planSlug) url += `?plan=${encodeURIComponent(planSlug)}`;
    chrome.tabs.create({ url });
  }

  function openLoginPage() {
    chrome.tabs.create({ url: `${HOST}/pay/${extensionId}#login` });
  }

  function startBackground() {
    chrome.runtime.onInstalled.addListener(async (details) => {
      if (details.reason === 'install') {
        const stored = await getStoredUser();
        if (!stored) {
          await setStoredUser({ paid: false, paidPlan: null, installedAt: new Date().toISOString() });
        }
      }
    });

    chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
      if (msg.type === 'EXTPAY_GET_USER') {
        getUser().then(u => sendResponse({ success: true, user: u }))
                 .catch(e => sendResponse({ success: false, error: e.message }));
        return true;
      }
    });
  }

  return { getUser, openPaymentPage, openLoginPage, startBackground };
}

if (typeof module !== 'undefined') module.exports = ExtPay;
