// PurrFresh Cat Viewer — image always fills edge-to-edge
'use strict';

let scale        = 1;
let offsetX      = 0;
let offsetY      = 0;
let imgNaturalW  = 0;
let imgNaturalH  = 0;
let currentImage = null;

const MIN_SCALE  = 0.05;
const MAX_SCALE  = 12;
const ZOOM_STEP  = 0.12;

const viewport    = document.getElementById('viewport');
const container   = document.getElementById('img-container');
const img         = document.getElementById('viewer-img');
const loadOverlay = document.getElementById('loading-overlay');
const breedLabel  = document.getElementById('viewer-breed');
const statusZoom  = document.getElementById('status-zoom');
const statusSize  = document.getElementById('status-size');
const statusMsg   = document.getElementById('status-msg');

async function loadImage() {
  try {
    const result = await new Promise(resolve =>
      chrome.storage.local.get('_viewer_image', r => resolve(r._viewer_image))
    );
    if (!result?.url) { loadOverlay.classList.add('hidden'); return; }

    currentImage = result;
    document.title = result.breeds?.[0]?.name
      ? `${result.breeds[0].name} — PurrFresh` : 'PurrFresh Cat Viewer';
    if (result.breeds?.[0]?.name) breedLabel.textContent = result.breeds[0].name;

    if (result.width && result.height) {
      img.style.width  = result.width  + 'px';
      img.style.height = result.height + 'px';
    }

    img.onload = () => {
      imgNaturalW = img.naturalWidth  || result.width  || 800;
      imgNaturalH = img.naturalHeight || result.height || 600;
      if (!result.width || !result.height) {
        img.style.width  = imgNaturalW + 'px';
        img.style.height = imgNaturalH + 'px';
      }
      statusSize.textContent = `${imgNaturalW} × ${imgNaturalH}`;
      loadOverlay.classList.add('hidden');
      fillViewport();
    };
    img.onerror = () => { statusMsg.textContent = '😿 Failed to load'; loadOverlay.classList.add('hidden'); };
    img.src = result.url;
  } catch (err) {
    console.error(err); loadOverlay.classList.add('hidden');
  }
}

// Cover scale — image always touches all 4 sides, no background visible
function fillViewport() {
  if (!imgNaturalW || !imgNaturalH) return;
  scale   = Math.max(viewport.clientWidth / imgNaturalW, viewport.clientHeight / imgNaturalH);
  offsetX = 0; offsetY = 0;
  applyTransform(false);
}

function fitToWindow() {
  if (!imgNaturalW || !imgNaturalH) return;
  scale   = Math.min(viewport.clientWidth / imgNaturalW, viewport.clientHeight / imgNaturalH);
  offsetX = 0; offsetY = 0;
  applyTransform(true);
}

function applyTransform(animate = false) {
  if (animate) {
    container.classList.add('animating');
    setTimeout(() => container.classList.remove('animating'), 220);
  }

  // Minimum scale = cover (never reveal background)
  const coverScale = imgNaturalW
    ? Math.max(viewport.clientWidth / imgNaturalW, viewport.clientHeight / imgNaturalH)
    : MIN_SCALE;

  scale = Math.max(coverScale, Math.min(MAX_SCALE, scale));

  // Clamp pan: edges of image must stay at or beyond viewport edges
  if (imgNaturalW) {
    const scaledW = imgNaturalW * scale;
    const scaledH = imgNaturalH * scale;
    const maxX = Math.max(0, (scaledW - viewport.clientWidth)  / 2);
    const maxY = Math.max(0, (scaledH - viewport.clientHeight) / 2);
    offsetX = Math.max(-maxX, Math.min(maxX, offsetX));
    offsetY = Math.max(-maxY, Math.min(maxY, offsetY));
  }

  container.style.transform =
    `translate(calc(-50% + ${offsetX}px), calc(-50% + ${offsetY}px)) scale(${scale})`;
  statusZoom.textContent = `${Math.round(scale * 100)}%`;
}

function setScale(newScale, pivotX, pivotY) {
  const vw  = viewport.clientWidth;
  const vh  = viewport.clientHeight;
  const cx  = pivotX ?? vw / 2;
  const cy  = pivotY ?? vh / 2;
  const imgCX = vw / 2 + offsetX;
  const imgCY = vh / 2 + offsetY;
  const dx = cx - imgCX, dy = cy - imgCY;
  const ratio = newScale / scale;
  offsetX += dx - dx * ratio;
  offsetY += dy - dy * ratio;
  scale = newScale;
  applyTransform();
}

// Drag
let isDragging = false, dragSX = 0, dragSY = 0, dragOX = 0, dragOY = 0;
viewport.addEventListener('mousedown', e => {
  if (e.button !== 0) return;
  isDragging = true; dragSX = e.clientX; dragSY = e.clientY; dragOX = offsetX; dragOY = offsetY;
  viewport.classList.add('grabbing'); e.preventDefault();
});
window.addEventListener('mousemove', e => {
  if (!isDragging) return;
  offsetX = dragOX + (e.clientX - dragSX);
  offsetY = dragOY + (e.clientY - dragSY);
  applyTransform();
});
window.addEventListener('mouseup', () => { isDragging = false; viewport.classList.remove('grabbing'); });

// Scroll zoom
viewport.addEventListener('wheel', e => {
  e.preventDefault();
  const d    = e.deltaY > 0 ? -ZOOM_STEP : ZOOM_STEP;
  const rect = viewport.getBoundingClientRect();
  setScale(scale * (1 + d), e.clientX - rect.left, e.clientY - rect.top);
}, { passive: false });

// Touch
let lastDist = 0;
viewport.addEventListener('touchstart', e => {
  if (e.touches.length === 1) { isDragging = true; dragSX = e.touches[0].clientX; dragSY = e.touches[0].clientY; dragOX = offsetX; dragOY = offsetY; }
  else if (e.touches.length === 2) { isDragging = false; lastDist = tDist(e); }
  e.preventDefault();
}, { passive: false });
viewport.addEventListener('touchmove', e => {
  if (e.touches.length === 1 && isDragging) { offsetX = dragOX + (e.touches[0].clientX - dragSX); offsetY = dragOY + (e.touches[0].clientY - dragSY); applyTransform(); }
  else if (e.touches.length === 2) { const d = tDist(e); const m = tMid(e); setScale(scale * (d / lastDist), m.x, m.y); lastDist = d; }
  e.preventDefault();
}, { passive: false });
viewport.addEventListener('touchend', () => { isDragging = false; });
function tDist(e) { const dx = e.touches[0].clientX - e.touches[1].clientX, dy = e.touches[0].clientY - e.touches[1].clientY; return Math.sqrt(dx*dx+dy*dy); }
function tMid(e)  { return { x: (e.touches[0].clientX + e.touches[1].clientX) / 2, y: (e.touches[0].clientY + e.touches[1].clientY) / 2 }; }

// Keyboard
document.addEventListener('keydown', e => {
  if (e.key === '=' || e.key === '+') setScale(scale * (1 + ZOOM_STEP * 2));
  else if (e.key === '-')  setScale(scale * (1 - ZOOM_STEP * 2));
  else if (e.key === '0' || e.key === 'Escape') fillViewport();
  else if (e.key === 'f')  fitToWindow();
  else if (e.key === 'ArrowLeft')  { offsetX -= 20; applyTransform(); }
  else if (e.key === 'ArrowRight') { offsetX += 20; applyTransform(); }
  else if (e.key === 'ArrowUp')    { offsetY -= 20; applyTransform(); }
  else if (e.key === 'ArrowDown')  { offsetY += 20; applyTransform(); }
});

// Buttons
document.getElementById('btn-zoom-in').addEventListener('click',  () => setScale(scale * (1 + ZOOM_STEP * 2)));
document.getElementById('btn-zoom-out').addEventListener('click', () => setScale(scale * (1 - ZOOM_STEP * 2)));
document.getElementById('btn-fit').addEventListener('click',  fitToWindow);
document.getElementById('btn-fill').addEventListener('click', fillViewport);
document.getElementById('btn-orig').addEventListener('click', () => { scale = 1; offsetX = 0; offsetY = 0; applyTransform(true); });

document.getElementById('btn-copy-url').addEventListener('click', async () => {
  if (!currentImage?.url) return;
  try { await navigator.clipboard.writeText(currentImage.url); }
  catch { const i = Object.assign(document.createElement('input'), { value: currentImage.url }); document.body.appendChild(i); i.select(); document.execCommand('copy'); i.remove(); }
  showMsg('URL copied! 🔗');
});

document.getElementById('btn-open-tab').addEventListener('click', () => {
  if (currentImage?.url) window.open(currentImage.url, '_blank');
});

// Resize
let rt;
window.addEventListener('resize', () => {
  clearTimeout(rt);
  rt = setTimeout(() => { if (img.complete && imgNaturalW) fillViewport(); }, 80);
});

let mt;
function showMsg(text, ms = 2500) {
  statusMsg.textContent = text;
  clearTimeout(mt);
  mt = setTimeout(() => { statusMsg.textContent = ''; }, ms);
}

loadImage();
