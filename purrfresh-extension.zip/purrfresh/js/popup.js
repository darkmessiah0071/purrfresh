// PurrFresh Popup — with instant preloaded cat + expand/viewer support
'use strict';

let state = {
  currentImage:  null,
  apiKey:        '',
  tier:          'free',
  extpayUser:    null,
  dailyCount:    0,
  totalCatsSeen: 0,
  favorites:     [],
  seenIds:       [],
  settings:      { theme: 'auto', showBreed: true },
  isLoading:     false,
  bufferSize:    0,
  plans: {
    free:     { dailyLimit: 10,       maxFavorites: 3        },
    monthly:  { dailyLimit: Infinity, maxFavorites: Infinity },
    yearly:   { dailyLimit: Infinity, maxFavorites: Infinity },
    lifetime: { dailyLimit: Infinity, maxFavorites: Infinity },
  },
};

const $    = id  => document.getElementById(id);
const $q   = sel => document.querySelector(sel);
const $all = sel => document.querySelectorAll(sel);

// ── Init ──────────────────────────────────────────────────────────────
async function init() {
  try {
    await loadState();
    applyTheme();
    updateUI();
    bindEvents();

    // Trigger buffer prefill in background
    chrome.runtime.sendMessage({ type: 'PREFILL_BUFFER' });

    // Show last-viewed image immediately (no wait)
    if (state.lastViewedImage) {
      displayCatInstant(state.lastViewedImage);
    }

    if (!state.apiKey) {
      // Silently use anonymous access — no banner shown to user
    }

  } catch (err) {
    showToast('error', '😿 Load Error', err.message);
    console.error('[PurrFresh] init:', err);
  }
}

async function loadState() {
  return new Promise((resolve, reject) => {
    chrome.runtime.sendMessage({ type: 'GET_STATE' }, (resp) => {
      if (chrome.runtime.lastError) return reject(chrome.runtime.lastError);
      if (!resp?.success) return reject(new Error(resp?.error || 'GET_STATE failed'));
      const d = resp.data;
      const today = getTodayString();

      state.apiKey          = d.apiKey || '';
      state.tier            = d.tier   || 'free';
      state.extpayUser      = d.extpayUser || null;
      state.dailyCount      = d.dailyDate === today ? (d.dailyCount || 0) : 0;
      state.totalCatsSeen   = d.totalCatsSeen || 0;
      state.favorites       = d.favorites || [];
      state.seenIds         = d.seenIds   || [];
      state.settings        = Object.assign({ theme: 'auto', showBreed: true }, d.settings || {});
      state.bufferSize      = d.bufferSize || 0;
      state.lastViewedImage = d.lastViewedImage || null;
      if (d.plans) state.plans = d.plans;

      $('api-key-input').value  = state.apiKey;
      $('toggle-dark').checked  = state.settings.theme === 'dark';
      $('toggle-breed').checked = state.settings.showBreed !== false;
      resolve();
    });
  });
}

function getTodayString() {
  return new Date().toISOString().slice(0, 10);
}

// ── Display an image instantly (no loading state) ─────────────────────
function displayCatInstant(image) {
  state.currentImage = image;
  const imgEl = $('cat-image');
  $('cat-placeholder').style.display = 'none';
  imgEl.classList.remove('loaded');
  imgEl.onload  = () => { imgEl.classList.add('loaded'); showBreedBadge(image); };
  imgEl.onerror = () => {};
  imgEl.src = image.url;
  updateFavButton();
  updateExpandButton();
}

// ── Full UI update ────────────────────────────────────────────────────
function updateUI() {
  const plan       = state.plans[state.tier] || state.plans.free;
  const isUnlim    = plan.dailyLimit === Infinity;
  const limit      = plan.dailyLimit;
  const hitLimit   = !isUnlim && state.dailyCount >= limit;
  const pct        = isUnlim ? 0 : Math.min(100, (state.dailyCount / limit) * 100);

  $('daily-bar-fill').style.width     = `${pct}%`;
  $('daily-count-label').textContent  = isUnlim
    ? `${state.dailyCount} today (unlimited 🎉)`
    : `${state.dailyCount} / ${limit}`;
  $('daily-bar-fill').classList.toggle('full', pct >= 100);
  $('daily-bar-wrap').style.display   = isUnlim ? 'none' : 'block';
  $('limit-banner').classList.toggle('visible', hitLimit);

  $('btn-new-cat').disabled  = hitLimit || state.isLoading;
  $('stat-total').textContent = state.totalCatsSeen;
  $('stat-favs').textContent  = state.favorites.length;
  $('stat-streak').textContent = state.dailyCount;

  $('seen-count-label').textContent = `${state.seenIds.length} cats seen so far`;
  $('fav-count-label').textContent  = `${state.favorites.length} favorites saved`;

  // Buffer indicator
  const bufEl = $('buffer-indicator');
  if (bufEl) {
    bufEl.textContent = state.bufferSize > 0
      ? `⚡ ${state.bufferSize} cats ready`
      : '⏳ loading…';
    bufEl.className = state.bufferSize > 0 ? 'buffer-chip ready' : 'buffer-chip loading';
  }

  // Upgrade tab badges
  ['free','monthly','yearly','lifetime'].forEach(t => {
    const badge = $(`badge-${t}`);
    const card  = $(`tier-${t}`);
    if (badge) badge.style.display = t === state.tier ? 'inline-block' : 'none';
    if (card)  card.classList.toggle('current', t === state.tier);
  });

  const manageSub = $('btn-manage-sub');
  if (manageSub) manageSub.style.display = state.tier !== 'free' ? 'flex' : 'none';

  updateFavButton();
  updateExpandButton();
  renderFavorites();
}

function updateFavButton() {
  if (!state.currentImage) { $('btn-fav').textContent = '🤍'; $('btn-fav').classList.remove('is-fav'); return; }
  const isFav = state.favorites.some(f => f.id === state.currentImage.id);
  $('btn-fav').textContent = isFav ? '💛' : '🤍';
  $('btn-fav').classList.toggle('is-fav', isFav);
}

function updateExpandButton() {
  const btn = $('btn-expand');
  if (btn) btn.style.opacity = state.currentImage ? '1' : '0.4';
}

// ── Events ────────────────────────────────────────────────────────────
function bindEvents() {
  // Tabs
  $all('.tab-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      $all('.tab-btn').forEach(b => b.classList.remove('active'));
      $all('.tab-content').forEach(t => t.classList.remove('active'));
      btn.classList.add('active');
      document.querySelector(`.tab-content[data-tab="${btn.dataset.tab}"]`).classList.add('active');
    });
  });

  $('btn-new-cat').addEventListener('click', fetchNewCat);
  $('btn-fav').addEventListener('click', toggleFavorite);

  // Expand — opens the cat viewer window
  $('btn-expand').addEventListener('click', openInViewer);

  // Double-click image also opens viewer
  $('cat-image').addEventListener('dblclick', openInViewer);
  $('cat-image-wrap').addEventListener('dblclick', openInViewer);

  $('btn-share').addEventListener('click', async () => {
    if (!state.currentImage) { showToast('info','🐾 No cat yet','Fetch a cat first!'); return; }
    try {
      await navigator.clipboard.writeText(state.currentImage.url);
      showToast('success','🔗 Copied!','Image URL copied.');
    } catch {
      showToast('error','😿 Copy failed','Could not access clipboard.');
    }
  });

  $('btn-theme').addEventListener('click', () => {
    const dark = document.documentElement.getAttribute('data-theme') === 'dark';
    state.settings.theme = dark ? 'light' : 'dark';
    $('toggle-dark').checked = !dark;
    applyTheme(); saveSettings();
  });

  $('toggle-dark').addEventListener('change', () => {
    state.settings.theme = $('toggle-dark').checked ? 'dark' : 'light';
    applyTheme(); saveSettings();
  });

  $('toggle-breed').addEventListener('change', () => {
    state.settings.showBreed = $('toggle-breed').checked;
    if (state.currentImage) showBreedBadge(state.currentImage);
    saveSettings();
  });

  $('btn-save-key').addEventListener('click', saveApiKey);
  $('api-key-input').addEventListener('keydown', e => { if (e.key === 'Enter') saveApiKey(); });

  $('btn-reset-seen').addEventListener('click', () => {
    showModal({
      icon: '🔄', title: 'Reset Seen List?',
      body: `You've seen ${state.seenIds.length} cats. Reset means cats may repeat.`,
      primaryLabel: 'Yes, Reset', secondaryLabel: 'Cancel',
      onPrimary: async () => {
        await chrome.runtime.sendMessage({ type: 'RESET_SEEN' });
        state.seenIds = []; closeModal();
        showToast('success','✅ Reset!','Seen list cleared. Buffer refilling…');
        updateUI();
      },
      onSecondary: closeModal,
    });
  });

  $('btn-clear-favs').addEventListener('click', () => {
    if (!state.favorites.length) { showToast('info','💛 Empty','No favorites to clear.'); return; }
    showModal({
      icon: '🗑️', title: 'Clear All Favorites?',
      body: `Remove all ${state.favorites.length} saved cats?`,
      primaryLabel: 'Clear All', secondaryLabel: 'Cancel',
      onPrimary: async () => {
        state.favorites = [];
        await chrome.storage.local.set({ favorites: [] });
        closeModal(); showToast('success','✅ Cleared','All favorites removed.'); updateUI();
      },
      onSecondary: closeModal,
    });
  });

  $('btn-export-favs').addEventListener('click', exportFavorites);
  $('btn-upgrade-from-limit').addEventListener('click', () => $q('.tab-btn[data-tab="upgrade"]').click());

  // Payment buttons
  $('btn-upgrade-monthly').addEventListener('click',  () => openPayment('monthly'));
  $('btn-upgrade-yearly').addEventListener('click',   () => openPayment('yearly'));
  $('btn-upgrade-lifetime').addEventListener('click', () => openPayment('lifetime'));
  $('btn-manage-sub').addEventListener('click', () => {
    chrome.runtime.sendMessage({ type: 'OPEN_LOGIN' });
    showToast('info','🔑 Opening…','Manage your subscription in the new tab.');
  });
  $('btn-refresh-status').addEventListener('click', refreshPaymentStatus);

  $('btn-review').addEventListener('click', () => {
    chrome.tabs.create({ url: 'https://chrome.google.com/webstore/detail/mdkenbajidgplificinngoiicipjlepof/reviews' });
  });
}

// ── Open viewer window ────────────────────────────────────────────────
function openInViewer() {
  if (!state.currentImage) { showToast('info','🐾 No cat yet','Fetch a cat first!'); return; }
  chrome.runtime.sendMessage({ type: 'OPEN_VIEWER', image: state.currentImage });
  showToast('success','🔍 Opening viewer','Pan, zoom and resize in the new window!', { duration: 3000 });
}

// ── Fetch cat ─────────────────────────────────────────────────────────
async function fetchNewCat() {
  if (state.isLoading) return;
  const plan = state.plans[state.tier] || state.plans.free;
  if (plan.dailyLimit !== Infinity && state.dailyCount >= plan.dailyLimit) {
    $('limit-banner').classList.add('visible');
    showToast('warning','😿 Daily Limit',`You've had your ${plan.dailyLimit} cats today!`);
    return;
  }

  state.isLoading = true;
  $('btn-new-cat').disabled   = true;
  $('btn-new-cat').textContent = state.bufferSize > 0 ? '⚡ Loading…' : '⏳ Fetching…';
  $('spinner').classList.add('visible');
  $('cat-image').classList.remove('loaded');
  $('breed-badge').classList.remove('visible');

  try {
    const result = await new Promise((resolve, reject) => {
      chrome.runtime.sendMessage({ type: 'FETCH_CAT', apiKey: state.apiKey }, (resp) => {
        if (chrome.runtime.lastError) return reject(chrome.runtime.lastError);
        if (!resp?.success) return reject(new Error(resp?.error || 'FETCH_CAT failed'));
        resolve(resp.data);
      });
    });

    state.currentImage   = result;
    state.dailyCount     = result.dailyCount;
    state.totalCatsSeen  = result.totalSeen;
    state.bufferSize     = Math.max(0, state.bufferSize - 1);
    state.seenIds        = [...state.seenIds, result.id];

    displayCatInstant(result);
    updateUI();

  } catch (err) {
    handleFetchError(err);
  } finally {
    state.isLoading = false;
    const p2 = state.plans[state.tier] || state.plans.free;
    $('btn-new-cat').disabled   = p2.dailyLimit !== Infinity && state.dailyCount >= p2.dailyLimit;
    $('btn-new-cat').textContent = '🐱 New Cat';
    $('spinner').classList.remove('visible');
  }
}

function showBreedBadge(image) {
  const badge = $('breed-badge');
  if (state.settings.showBreed && image?.breeds?.[0]?.name) {
    badge.textContent = image.breeds[0].name;
    badge.classList.add('visible');
  } else {
    badge.classList.remove('visible');
  }
}

function handleFetchError(err) {
  $('spinner').classList.remove('visible');
  const msg = err.message || '';
  if (msg === 'NETWORK_ERROR')       return showToast('error','📡 Offline','Check your connection.',{retry:true});
  if (msg === 'RATE_LIMITED')        return showToast('warning','⏸️ Rate Limited','Too many requests 😺 Wait a moment then retry.',{retry:true, duration:8000});
  if (msg === 'INVALID_KEY')         return showToast('error','🔑 Bad API Key','Check your key in Settings.');
  if (msg === 'DAILY_LIMIT_REACHED') return $('limit-banner').classList.add('visible');
  if (msg === 'ALL_CATS_SEEN') {
    showModal({
      icon:'🌍', title:"You've Seen Every Cat!",
      body:"You've seen every unique cat in existence! Reset your seen list to start fresh?",
      primaryLabel:'🔄 Reset & Continue', secondaryLabel:'Not Yet',
      onPrimary: async () => {
        await chrome.runtime.sendMessage({ type: 'RESET_SEEN' });
        state.seenIds = []; closeModal(); updateUI(); fetchNewCat();
      },
      onSecondary: closeModal,
    });
    return;
  }
  showToast('error','😿 Something Went Wrong',`${msg || 'Unknown error'}`,{retry:true});
}

// ── Favorites ─────────────────────────────────────────────────────────
async function toggleFavorite() {
  if (!state.currentImage) { showToast('info','🐾 No cat yet','Fetch a cat first!'); return; }
  const plan = state.plans[state.tier] || state.plans.free;
  const idx  = state.favorites.findIndex(f => f.id === state.currentImage.id);
  if (idx >= 0) {
    state.favorites.splice(idx, 1);
    showToast('info','💔 Removed','Cat removed from favorites.');
  } else {
    if (plan.maxFavorites !== Infinity && state.favorites.length >= plan.maxFavorites) {
      showToast('warning','💛 Full',`Free plan: ${plan.maxFavorites} max. Upgrade for unlimited!`);
      return;
    }
    state.favorites.unshift({ id: state.currentImage.id, url: state.currentImage.url, savedAt: new Date().toISOString() });
    $('btn-fav').classList.add('favorited');
    setTimeout(() => $('btn-fav').classList.remove('favorited'), 400);
    showToast('success','💛 Saved!','Cat added to favorites!');
  }
  await chrome.storage.local.set({ favorites: state.favorites });
  updateUI();
}

function renderFavorites() {
  const grid = $('favorites-grid');
  const empty = $('empty-favs');
  grid.innerHTML = '';
  if (!state.favorites.length) { empty.style.display = 'block'; return; }
  empty.style.display = 'none';
  state.favorites.forEach((fav, idx) => {
    const div = document.createElement('div');
    div.className = 'fav-thumb';
    div.innerHTML = `<img src="${fav.url}" alt="Saved cat" loading="lazy" /><div class="fav-remove" data-idx="${idx}">✕</div>`;
    div.querySelector('img').addEventListener('click', () => {
      state.currentImage = fav;
      displayCatInstant(fav);
      $q('.tab-btn[data-tab="cats"]').click();
    });
    div.querySelector('.fav-remove').addEventListener('click', async (e) => {
      e.stopPropagation();
      state.favorites.splice(parseInt(e.target.dataset.idx), 1);
      await chrome.storage.local.set({ favorites: state.favorites });
      renderFavorites();
      updateFavButton();
      $('stat-favs').textContent = state.favorites.length;
    });
    grid.appendChild(div);
  });
}

async function exportFavorites() {
  if (!['yearly','lifetime'].includes(state.tier)) {
    showToast('warning','⭐ Premium','Export needs Yearly or Lifetime plan.'); return;
  }
  if (!state.favorites.length) { showToast('info','💛 Empty','No favorites to export.'); return; }
  const blob = new Blob([JSON.stringify(state.favorites, null, 2)], { type: 'application/json' });
  const url  = URL.createObjectURL(blob);
  const a    = Object.assign(document.createElement('a'), { href: url, download: `purrfresh-fav-${getTodayString()}.json` });
  a.click(); URL.revokeObjectURL(url);
  showToast('success','📦 Exported!',`${state.favorites.length} favorites exported.`);
}

// ── Settings ──────────────────────────────────────────────────────────
async function saveApiKey() {
  const key = $('api-key-input').value.trim();
  state.apiKey = key;
  await chrome.storage.local.set({ apiKey: key });
  $('api-key-status').textContent = key ? '✅ Saved!' : 'No key set';
  $('api-key-status').style.color = key ? 'var(--teal)' : 'var(--text-l)';

  showToast(key ? 'success' : 'info', key ? '🔑 Key Saved' : '🔑 Cleared', key ? 'Higher rate limits active.' : 'Using anonymous access.');
  setTimeout(() => { $('api-key-status').textContent = ''; }, 3000);
}

async function saveSettings() {
  await chrome.storage.local.set({ settings: state.settings });
}

function applyTheme() {
  const t    = state.settings.theme;
  const dark = t === 'dark' || (t === 'auto' && window.matchMedia('(prefers-color-scheme: dark)').matches);
  document.documentElement.setAttribute('data-theme', dark ? 'dark' : '');
  $('btn-theme').textContent = dark ? '☀️' : '🌙';
}

// ── Payment ───────────────────────────────────────────────────────────
function openPayment(planSlug) {
  chrome.runtime.sendMessage({ type: 'OPEN_PAYMENT', planSlug }, () => {
    showToast('info','💳 Payment Page Opening','Complete purchase in the new tab, then click Refresh below.', { duration: 6000 });
  });
}

async function refreshPaymentStatus() {
  showToast('info','🔄 Checking…','Verifying payment…');
  $('btn-refresh-status').disabled = true;
  try {
    const resp = await new Promise((resolve, reject) => {
      chrome.runtime.sendMessage({ type: 'REFRESH_USER' }, r => {
        if (chrome.runtime.lastError) return reject(chrome.runtime.lastError);
        resolve(r);
      });
    });
    if (resp.success && resp.user?.paid) {
      const names = { monthly:'Monthly', yearly:'Yearly', lifetime:'Lifetime' };
      state.tier = resp.user.paidPlan || 'monthly';
      state.extpayUser = resp.user;
      showToast('success','🎉 Plan Activated!',`Welcome to ${names[state.tier]}! Unlimited cats!`, { duration: 5000 });
      updateUI();
    } else {
      showToast('warning','😺 Not Found','No completed payment found. Try again after checkout.');
    }
  } catch (e) {
    showToast('error','😿 Error', e.message);
  } finally {
    $('btn-refresh-status').disabled = false;
  }
}

// ── Toast ─────────────────────────────────────────────────────────────
function showToast(type, title, message, opts = {}) {
  const icons = { error:'😿', success:'😸', warning:'🙀', info:'😺' };
  const t = document.createElement('div');
  t.className = `toast toast-${type}`;
  t.innerHTML = `
    <span class="toast-icon">${icons[type]||'😺'}</span>
    <div class="toast-body">
      <div class="toast-title">${title}</div>
      ${message ? `<div class="toast-msg">${message}</div>` : ''}
      ${opts.retry ? `<button class="btn-text retry-btn" style="margin-top:3px;font-size:11px">Retry ↺</button>` : ''}
    </div>
    <button class="toast-close" onclick="this.parentElement.remove()">✕</button>`;
  if (opts.retry) t.querySelector('.retry-btn')?.addEventListener('click', () => { t.remove(); fetchNewCat(); });
  $('toast-container').appendChild(t);
  const dur = opts.duration || (type === 'error' ? 7000 : 3800);
  setTimeout(() => { t.classList.add('removing'); setTimeout(() => t.remove(), 220); }, dur);
}

// ── Modal ─────────────────────────────────────────────────────────────
let _cb = {};
function showModal({ icon, title, body, primaryLabel, secondaryLabel, onPrimary, onSecondary }) {
  $('modal-icon').textContent = icon; $('modal-title').textContent = title;
  $('modal-body').textContent = body; $('modal-primary').textContent = primaryLabel;
  $('modal-secondary').textContent = secondaryLabel || '';
  $('modal-secondary').style.display = secondaryLabel ? 'block' : 'none';
  _cb = { onPrimary, onSecondary };
  $('modal-overlay').classList.add('visible');
}
function closeModal() { $('modal-overlay').classList.remove('visible'); }
$('modal-primary').addEventListener('click',   () => _cb.onPrimary?.());
$('modal-secondary').addEventListener('click', () => _cb.onSecondary?.());
$('modal-overlay').addEventListener('click', e => { if (e.target === $('modal-overlay')) closeModal(); });

// ── Boot ──────────────────────────────────────────────────────────────
init().catch(console.error);
