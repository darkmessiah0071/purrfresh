# PurrFresh — Chrome Web Store Listing (Complete)

---

## DASHBOARD FIELDS

### Extension Name
```
PurrFresh Daily Cat Photos FREE
```
*(Exactly matches manifest "name" — required)*

### Summary (132 chars max)
```
A new, unique cat photo every day — never the same one twice! Daily fresh cats delivered to your browser.
```

### Detailed Description (up to 16,000 chars — use this full version)

```
🐾 PurrFresh — A Fresh Cat Photo Every Day, Guaranteed Never Repeated

Open PurrFresh and instantly see a beautiful, unique cat photo — one you've never seen before. Our intelligent duplicate-prevention system tracks every photo you've ever been shown and makes sure you never see the same cat twice. Ever.

✨ WHY PURRFRESH?

Most cat photo extensions recycle the same handful of images. PurrFresh is different. It connects to a database of hundreds of thousands of real cat photos, remembers every single one you've seen, and always delivers something new.

⚡ INSTANT CATS — NO WAITING

PurrFresh pre-loads a buffer of cat photos in the background so your next cat is always ready the moment you click. No spinner. No delay. Just cats.

🔍 EXPANDABLE VIEWER

Click the expand button (or double-click any photo) to open a full viewer window. Pan by dragging, zoom with your scroll wheel or pinch gestures, and resize the window — the image always fills edge to edge with no black borders.

🌟 FEATURES

• ✅ Never shows the same cat photo twice — ever
• ⚡ Instant photo delivery from pre-loaded buffer
• 💛 Save your favorite cats with one click
• 🔍 Expandable full-screen viewer with zoom & pan
• 🌙 Dark mode support
• 🐾 Breed identification — see the cat's breed on the photo
• 🔗 Copy image URL with one click
• 📊 Daily stats — track how many cats you've seen
• 🔒 100% private — all data stored locally, nothing sent to us

📋 FREE PLAN
• 10 unique new cats per day
• Save up to 3 favorites

⭐ PREMIUM PLANS (via secure in-app purchase)
• Monthly ($7/mo): Unlimited daily cats + unlimited favorites
• Yearly ($71/yr): Everything in Monthly + export favorites
• Lifetime ($245 one-time): Everything forever + custom themes + priority updates

🔑 OPTIONAL API KEY
PurrFresh works out of the box with no setup. If you want higher rate limits (useful if you're going through cats very fast), you can optionally add a free API key from thecatapi.com — it takes 30 seconds and is completely free.

🔒 PRIVACY FIRST
PurrFresh collects zero personal data. Your seen list, favorites, and settings are stored only on your device and never transmitted anywhere. See our full privacy policy for details.

Powered by The Cat API (thecatapi.com) — the world's largest cat photo database.

Questions or feedback? Leave a review or contact us through the Chrome Web Store.

🐱 Join 12,000+ cat lovers already using PurrFresh!
```

---

### Category
```
Photos
```
*(Primary category — fits best. Alternatively: "Fun" or "Lifestyle")*

### Language
```
English
```

### Homepage URL
```
https://github.com/darkmessiah0071/purrfresh
```
*(Replace with your actual GitHub repo URL)*

### Support URL  
```
https://github.com/darkmessiah0071/purrfresh/issues
```

### Privacy Policy URL
```
https://github.com/darkmessiah0071/purrfresh/blob/main/PRIVACY_POLICY.md
```
*(Host the PRIVACY_POLICY.md file in your GitHub repo)*

---

## PRIVACY PRACTICES (Data Use Disclosures)

In the "Privacy practices" section of the dashboard, answer as follows:

**Does your extension collect any user data?**  
→ ✅ **No** — select "This extension does not collect or use personal data"

**If asked about specific data types, answer NO to all:**
- User activity: NO
- Website content: NO
- Personally identifiable information: NO
- Health information: NO
- Financial / payment information: NO *(ExtensionPay handles this — you never see it)*
- Authentication information: NO
- Personal communications: NO
- Location: NO

---

## STORE GRAPHICS (what you need to create)

### Required: Extension Icon
- Already included: 128×128px PNG in `icons/icon128.png`
- Must be clean, no misleading elements ✅

### Required: At least 1 Screenshot (1280×800 OR 640×400)
**Recommended screenshots to take:**

1. **Main popup — cat loaded**
   - Show the popup with a beautiful cat photo, daily bar, stats
   - Caption: "A new unique cat photo every time — never repeated"

2. **Expanded viewer**
   - Show the catviewer.html window with a large cat filling the frame
   - Caption: "Expandable viewer — zoom, pan, and resize"

3. **Favorites grid**
   - Show 6+ saved favorites in the grid
   - Caption: "Save your favorites with one click"

4. **Upgrade/pricing tab**
   - Show the pricing cards
   - Caption: "Upgrade for unlimited cats"

5. **Dark mode**
   - Show popup in dark mode with a cat photo
   - Caption: "Beautiful dark mode included"

### Optional: Promotional Images
- Small tile: 440×280px
- Marquee: 1400×560px
- These are optional but help with discoverability

---

## REVIEWER NOTES (paste this in "Notes for reviewer" field)

```
Hi reviewer,

Thank you for reviewing PurrFresh Daily Cat Photos FREE.

WHAT THE EXTENSION DOES:
PurrFresh fetches cat photos from The Cat API (api.thecatapi.com), 
displays them in a popup, and tracks which photos have been shown 
to prevent repetition. Users can save favorites and expand photos 
in a viewer window.

HOW TO TEST:
1. Click the PurrFresh icon in the toolbar
2. Click "🐱 New Cat" to fetch a cat photo
3. Click the ⤢ button or double-click the photo to open the viewer
4. Go to Settings tab to see data options
5. Go to Upgrade tab to see pricing (no purchase required to test)

PERMISSIONS EXPLANATION:
• storage — saves seen image IDs, favorites, and settings locally
• alarms — resets daily counter at midnight via chrome.alarms API
• tabs — opens payment page (extensionpay.com) and cat viewer
• windows — opens the expandable cat photo viewer as a popup window

PAYMENTS:
Premium features use ExtensionPay (extensionpay.com), a compliant 
third-party payment processor for Chrome extensions. No payment 
is required to use the free tier (10 cats/day).

EXTERNAL CONNECTIONS:
• api.thecatapi.com — fetches cat photos (no user data sent)
• extensionpay.com — payment verification only (no data collected by us)

No user data is collected or transmitted to any servers we operate.
Full privacy policy: https://github.com/darkmessiah0071/purrfresh/blob/main/PRIVACY_POLICY.md
```

---

## PRE-SUBMISSION CHECKLIST

### Manifest
- [x] Manifest V3 ✅
- [x] All permissions are used (no unused permissions) ✅
- [x] Host permissions scoped to specific domains only ✅
- [x] No `<all_urls>` permissions ✅
- [x] `web_accessible_resources` scoped with `matches` ✅

### Code Quality
- [x] No `eval()` or remote code execution ✅
- [x] No obfuscated/minified code ✅
- [x] All scripts included in package (no CDN-loaded JS) ✅
- [x] No cryptocurrency mining ✅
- [x] No ad injection ✅

### Listing Quality
- [ ] At least 1 screenshot uploaded (1280×800)
- [ ] Icon 128×128 uploaded ✅
- [ ] Detailed description filled in
- [ ] Privacy policy URL set to GitHub
- [ ] Support URL set
- [ ] Homepage URL set
- [ ] Category selected: Photos
- [ ] Reviewer notes added

### Privacy
- [x] Privacy policy written and hosted on GitHub ✅
- [x] Data use disclosures answered accurately ✅
- [x] No collection of personal data ✅
- [x] ExtensionPay handles payments (we don't touch card data) ✅

### Account
- [ ] 2-Step Verification enabled on your Google account (REQUIRED)
- [ ] One-time $5 developer registration fee paid
- [ ] Extension zipped correctly (zip the CONTENTS of the folder, not the folder itself)

---

## HOW TO ZIP FOR SUBMISSION

**IMPORTANT:** Chrome Web Store requires you to zip the **contents** of the extension folder, not the folder itself.

```bash
# CORRECT way:
cd purrfresh/
zip -r ../purrfresh-submission.zip . -x "*.DS_Store" -x "__MACOSX/*"

# WRONG way (will be rejected):
zip -r purrfresh.zip purrfresh/   ← DON'T do this
```

After zipping, test it locally:
1. Go to `chrome://extensions`
2. Enable Developer Mode
3. Click "Load unpacked" → select the `purrfresh/` folder (not the zip)
4. Verify everything works before uploading the zip

---

## AFTER SUBMISSION

- Review typically takes **1–3 business days**
- Complex/new developer accounts may take up to **1–2 weeks**
- You'll receive an email at your Google account's address
- If rejected, read the rejection code carefully and fix before resubmitting
- You get **one appeal** per rejection — don't waste it without fixing the issue first
