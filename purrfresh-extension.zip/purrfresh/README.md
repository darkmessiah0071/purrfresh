# 🐱 PurrFresh – Daily New Cat Photos Chrome Extension

A delightful Manifest V3 Chrome extension that shows you a **unique cat photo every time**, guaranteed never to repeat.

---

## 📦 Installation

1. Open Chrome and navigate to `chrome://extensions`
2. Enable **Developer Mode** (toggle in top-right)
3. Click **"Load unpacked"**
4. Select the `purrfresh/` folder
5. PurrFresh will appear in your extensions bar — click the 🐱 icon!

---

## 🔑 Getting a Free API Key

For best results (higher rate limits), get a free API key from TheCatAPI:
1. Visit [https://thecatapi.com](https://thecatapi.com) and click **Sign Up**
2. Check your email for your free API key (starts with `live_`)
3. Open PurrFresh → **Settings** tab → paste your key → **Save**

You can use PurrFresh without a key (10 cats/day limit applies).

---

## ✨ Features

| Feature | Free | Monthly ($4.99/mo) | Yearly ($39.99/yr) | Lifetime ($99) |
|---------|------|-------------------|-------------------|----------------|
| Cats per day | 10 | Unlimited | Unlimited | Unlimited |
| Favorites | 3 | Unlimited | Unlimited | Unlimited |
| Export favorites | ❌ | ❌ | ✅ | ✅ |
| Custom themes | ❌ | ❌ | ❌ | ✅ |
| No repeated cats | ✅ | ✅ | ✅ | ✅ |

---

## 🏗️ File Structure

```
purrfresh/
├── manifest.json          # MV3 manifest
├── popup.html             # Main UI
├── css/
│   └── popup.css          # All styles (Comfortaa + Nunito fonts)
├── js/
│   ├── background.js      # Service worker (daily reset, storage)
│   └── popup.js           # Full UI logic
└── icons/
    ├── icon16.png
    ├── icon32.png
    ├── icon48.png
    └── icon128.png
```

---

## 🛠️ Technical Notes

- **Uniqueness**: All seen image IDs stored in `chrome.storage.local` — photos never repeat
- **Daily Reset**: Background service worker resets daily counter at midnight via Chrome Alarms API
- **Error Handling**: Full coverage — network errors, rate limits, invalid keys, storage quota, "all cats seen" edge case
- **Privacy**: Zero external data collection; everything stored locally

---

## 🚀 Post-MVP Roadmap

- [ ] Real Stripe payment integration for 4 tiers
- [ ] New-tab replacement page (premium)
- [ ] Cat breed / mood filters
- [ ] Shareable cat cards
- [ ] Push notifications for daily cat reminders
